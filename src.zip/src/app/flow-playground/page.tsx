// src/app/dev/flow-playground/page.tsx (optional)
"use client";
import { useMemo } from "react";
import FlowRenderer from "@/modules/flow-layout/FlowRenderer";
import {
  SECTION_CATALOG,
  TEMPLATE_LONGFORM_A,
} from "@/modules/flow-layout/presets";
import "@/modules/flow-layout/flow-layout.css";

const SAMPLE_TEXT = `
Luke’s Church is a colonial-era Anglican church located in Abbottabad, in the Khyber Pakhtunkhwa province of Pakistan. It was named after St. Luke, one of the companions of Jesus Christ. The church was established in 1864 to serve the spiritual and social needs of British military officers and their families stationed in the cantonment town.

Following the relocation of the Hazara district’s headquarters from the Sikh capital of Haripur, the new cantonment town was named aftert. Luke’s Church is a colonial-era Anglican church located in Abbottabad, in the Khyber Pakhtunkhwa province of Pakistan. It was named after St. Luke, one of the companions of Jesus Christ. The church was established in 1864 to serve the spiritual and social needs of British military officers and their families stationed in the cantonment town. When the British arrived in Abbottabad, there was a growing requirement for a place of worship, congregation, and marriage ceremonies for the Christian members of the military. Major James Abbott, who played a pivotal role in the development of the city and served as the first Deputy Commissioner of Hazara District after its annexation by the British in 1849, was instrumental in the region's early administratio.

Following the relocation of the Hazara district’s headquarters from the Sikh capital of Haripur, the new cantonment town was named aftert. Luke’s Church is a colonial-era Anglican church located in Abbottabad, in the Khyber Pakhtunkhwa province of Pakistan. It was named after St. Luke, one of the companions of Jesus Christ.
...
The church was established in 1864 to serve the spiritual and social needs of British military officers and their families stationed in the cantonment town. When the British arrived in Abbottabad, there was a growing requirement for a place of worship, congregation, and marriage ceremonies for the Christian members of the military. This necessity led to the founding of the church in the heart of the city. The construction of the church took six years to complete. It served as the military church for the British garrison in Abbottabad, which had been formally established in 1853. Major James Abbott, who played a pivotal role in the development of the city and served as the first Deputy Commissioner of Hazara District after its annexation by the British in 1849, was instrumental in the region's early administration. Following the relocation of the Hazara district’s headquarters from the Sikh capital of Haripur, the new cantonment town was named after
`;

export default function Page() {
  const input = useMemo(
    () => ({
      text: SAMPLE_TEXT.trim(),
      sectionCatalog: SECTION_CATALOG,
      template: TEMPLATE_LONGFORM_A,
      breakpoint: "desktop" as const,
    }),
    []
  );

  return (
    <FlowRenderer
      input={input}
      imagesBySlot={{
        hero: null, // show placeholder; attach an image by providing {storagePath, alt, caption}
        slot_1: null,
      }}
      sectionClassFor={({ sectionTypeId }) =>
        `hop-section sec-${sectionTypeId}`
      }
      textClassFor={({ sectionTypeId, blockId }) => `hop-text area-${blockId}`}
      imageClassFor={({ sectionTypeId, blockId }) =>
        `hop-media area-${blockId}`
      }
    />
  );
}
