// src/app/flow-smoke/page.tsx
"use client";

import React, { useMemo, useState } from "react";
import FlowComposer from "@/modules/flow-layout/FlowComposer";
import "@/modules/flow-layout/flow-layout.css";

/** Minimal inspector so we can see what FlowComposer received */
function DebugInspector({ data }: { data: any }) {
  return (
    <pre
      className="mt-4 text-xs bg-slate-50 border border-slate-200 rounded p-3 overflow-auto"
      style={{ maxHeight: 240 }}
    >
      {JSON.stringify(data, null, 2)}
    </pre>
  );
}

/** Local catalog keyed by SLUGS (FlowComposer will use sectionTypeId=slug) */
const CATALOG = {
  "full-width-text": {
    sectionTypeId: "full-width-text",
    geometry: {
      desktop: {
        widthPolicy: { type: "full" },
        heightPolicy: { type: "auto" },
      },
      tablet: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
      mobile: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
    },
    blocks: [
      {
        id: "txt_fw",
        kind: "text",
        acceptsTextFlow: true,
        textPolicy: { targetWords: 220 },
      },
    ],
    cssClass: "sec-full-width-text",
  },
  "full-width-image": {
    sectionTypeId: "full-width-image",
    geometry: {
      desktop: {
        widthPolicy: { type: "full" },
        heightPolicy: { type: "auto" },
      },
      tablet: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
      mobile: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
    },
    blocks: [{ id: "img_fw", kind: "image", imageSlotId: "fw_1" }],
    cssClass: "sec-full-width-image",
  },
  "image-left-text-right": {
    sectionTypeId: "image-left-text-right",
    geometry: {
      desktop: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      tablet: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      mobile: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
    },
    blocks: [
      { id: "img_l", kind: "image", imageSlotId: "left_1" },
      {
        id: "txt_r",
        kind: "text",
        acceptsTextFlow: true,
        textPolicy: { targetWords: 140 },
      },
    ],
    cssClass: "sec-img-left-text-right",
  },
  "image-right-text-left": {
    sectionTypeId: "image-right-text-left",
    geometry: {
      desktop: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      tablet: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      mobile: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
    },
    blocks: [
      {
        id: "txt_l",
        kind: "text",
        acceptsTextFlow: true,
        textPolicy: { targetWords: 140 },
      },
      { id: "img_r", kind: "image", imageSlotId: "right_1" },
    ],
    cssClass: "sec-img-right-text-left",
  },
  "two-images": {
    sectionTypeId: "two-images",
    geometry: {
      desktop: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      tablet: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      mobile: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
    },
    blocks: [
      { id: "img_1", kind: "image", imageSlotId: "pair_1" },
      { id: "img_2", kind: "image", imageSlotId: "pair_2" },
    ],
    cssClass: "sec-two-images",
  },
  "three-images": {
    sectionTypeId: "three-images",
    geometry: {
      desktop: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      tablet: {
        widthPolicy: { type: "container" },
        heightPolicy: { type: "auto" },
      },
      mobile: { widthPolicy: { type: "full" }, heightPolicy: { type: "auto" } },
    },
    blocks: [
      { id: "img_1", kind: "image", imageSlotId: "tri_1" },
      { id: "img_2", kind: "image", imageSlotId: "tri_2" },
      { id: "img_3", kind: "image", imageSlotId: "tri_3" },
    ],
    cssClass: "sec-three-images",
  },
} as const;

const DEMO_TEMPLATES = [
  { id: "basic", name: "Basic (Text only)", slugs: ["full-width-text"] },
  {
    id: "intro-L",
    name: "Intro (Image L / Text R)",
    slugs: ["image-left-text-right", "full-width-text"],
  },
  {
    id: "intro-R",
    name: "Intro (Image R / Text L)",
    slugs: ["image-right-text-left", "full-width-text"],
  },
  {
    id: "feature",
    name: "Feature Image + Text",
    slugs: ["full-width-image", "full-width-text"],
  },
  {
    id: "gallery-2",
    name: "Two-up Gallery + Text",
    slugs: ["two-images", "full-width-text"],
  },
  {
    id: "gallery-3",
    name: "Three-up Gallery + Text",
    slugs: ["three-images", "full-width-text"],
  },
];

export default function FlowSmoke() {
  const [tplId, setTplId] = useState("intro-L");
  const [text, setText] = useState(
    [
      "Islamia College Peshawar stands as one of the most remarkable architectural specimens in Pakistan, admired for both its historical importance and distinctive design.",
      "Founded in 1913, the college’s architectural character is rooted in the Indo-Saracenic Revival style.",
      "Across courtyards, arcades, and domes, the layout balances symmetry with local climate needs.",
    ].join(" ")
  );

  const template = useMemo(() => {
    const t = DEMO_TEMPLATES.find((x) => x.id === tplId)!;
    return {
      id: t.id,
      name: t.name,
      sections: t.slugs.map((slug) => ({ sectionTypeId: slug })),
    };
  }, [tplId]);

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">FlowComposer Smoke Test</h1>

      <div className="grid gap-3 md:grid-cols-3 items-start">
        <div className="md:col-span-2 space-y-3">
          <textarea
            className="w-full rounded border border-slate-300 p-3 min-h-[140px]"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <select
            className="w-full rounded border border-slate-300 p-2"
            value={tplId}
            onChange={(e) => setTplId(e.target.value)}
          >
            {DEMO_TEMPLATES.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>

          <div className="mt-2">
            <FlowComposer
              key={`smoke_${tplId}_${template.sections.length}`}
              masterText={text}
              sectionCatalog={CATALOG}
              template={template}
              onPickImage={() =>
                new Promise((resolve) =>
                  resolve({
                    // placeholder images for testing
                    storagePath: `https://picsum.photos/seed/${Math.random()
                      .toString(36)
                      .slice(2)}/1200/800`,
                    alt: "placeholder",
                    caption: null,
                    credit: null,
                  })
                )
              }
              onExport={({ layout, html }) => {
                // eslint-disable-next-line no-console
                console.log("SMOKE EXPORT", { layout, html });
              }}
            />
          </div>
        </div>

        <div className="md:col-span-1">
          <div className="rounded border border-slate-200 p-3 bg-white">
            <div className="text-sm font-semibold mb-2">Current Template</div>
            <DebugInspector data={template} />
            <div className="text-sm font-semibold mb-2">Catalog Keys</div>
            <DebugInspector data={Object.keys(CATALOG)} />
          </div>
        </div>
      </div>
    </div>
  );
}
