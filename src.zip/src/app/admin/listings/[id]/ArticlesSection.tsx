"use client";

import React, { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import FlowComposer from "@/modules/flow-layout/FlowComposer";
import {
  seedDefaultSectionTypes,
  loadArchetypeRows,
  loadTemplates,
  type SectionTypeRow,
} from "@/modules/flow-layout/db";
import { DEFAULT_SETTINGS } from "@/modules/flow-layout/default-sections";
import type { TemplateDef } from "@/modules/flow-layout/types";
import "@/modules/flow-layout/flow-layout.css";

/* ------------------------------------------------------------------ */
/* Small shared UI bits                                                */
/* ------------------------------------------------------------------ */

function FieldBlock({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="block">
      <div className="text-base font-semibold mb-1.5 text-gray-800">
        {label}
      </div>
      {children}
    </div>
  );
}
const inputStyles =
  "w-full bg-white border border-gray-300 rounded-md px-3 py-2";

/* ------------------------------------------------------------------ */
/* Supabase public URL helper                                          */
/* ------------------------------------------------------------------ */
async function publicUrl(bucket: string, key: string) {
  const { data } = supabase.storage.from(bucket).getPublicUrl(key);
  return data.publicUrl;
}

/* ------------------------------------------------------------------ */
/* Gallery Modal (for picking images into slots)                       */
/* ------------------------------------------------------------------ */
function GalleryBrowserModal({
  show,
  onClose,
  onImageSelect,
  siteId,
}: {
  show: boolean;
  onClose: () => void;
  onImageSelect: (image: {
    publicUrl: string;
    alt_text: string;
    caption: string | null;
  }) => void;
  siteId: string | number;
}) {
  const [images, setImages] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!show) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("site_images")
        .select("storage_path, alt_text, caption, sort_order")
        .eq("site_id", siteId)
        .order("sort_order", { ascending: false });

      if (error) {
        alert(error.message);
        setLoading(false);
        return;
      }
      const withUrls = await Promise.all(
        (data || []).map(async (r: any) => ({
          ...r,
          publicUrl: await publicUrl("site-images", r.storage_path),
        }))
      );
      if (!cancelled) {
        setImages(withUrls);
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [show, siteId]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">
            Select an Image
          </h3>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-800 text-2xl font-bold"
          >
            &times;
          </button>
        </div>
        <div className="p-4 overflow-y-auto">
          {loading ? (
            <p className="text-gray-600">Loading images…</p>
          ) : images.length ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {images.map((img) => (
                <div
                  key={img.publicUrl}
                  className="cursor-pointer group"
                  onClick={() => onImageSelect(img)}
                >
                  <img
                    src={img.publicUrl}
                    alt={img.alt_text || ""}
                    className="w-full h-32 object-cover rounded-md border"
                  />
                  <p className="text-xs text-gray-500 mt-1 truncate">
                    {img.alt_text || "No alt text"}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">
              No images found in the gallery for this site.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Section Catalog (5 image archetypes + Full-width Text)              */
/* We build a catalog keyed by section_type.id → { blocks: [...] }     */
/* ------------------------------------------------------------------ */
function catalogFromRows(rows: SectionTypeRow[]) {
  const bySlug: Record<
    string,
    {
      blocks: any[];
      cssClass?: string;
    }
  > = {
    "full-width-image": {
      blocks: [{ id: "img_fw", kind: "image", imageSlotId: "slot_fw_1" }],
      cssClass: "sec-full-width-image",
    },
    "full-width-text": {
      blocks: [
        {
          id: "txt_fw",
          kind: "text",
          acceptsTextFlow: true,
          textPolicy: { targetWords: 220 },
        },
      ],
      cssClass: "sec-full-width-text",
    },
    "image-left-text-right": {
      blocks: [
        { id: "img_l", kind: "image", imageSlotId: "slot_left" },
        {
          id: "txt_r",
          kind: "text",
          acceptsTextFlow: true,
          textPolicy: { targetWords: 140 },
        },
      ],
      cssClass: "sec-img-left-text-right",
    },
    "image-right-text-left": {
      blocks: [
        {
          id: "txt_l",
          kind: "text",
          acceptsTextFlow: true,
          textPolicy: { targetWords: 140 },
        },
        { id: "img_r", kind: "image", imageSlotId: "slot_right" },
      ],
      cssClass: "sec-img-right-text-left",
    },
    "two-images": {
      blocks: [
        { id: "img_1", kind: "image", imageSlotId: "slot_1" },
        { id: "img_2", kind: "image", imageSlotId: "slot_2" },
      ],
      cssClass: "sec-two-images",
    },
    "three-images": {
      blocks: [
        { id: "img_1", kind: "image", imageSlotId: "slot_1" },
        { id: "img_2", kind: "image", imageSlotId: "slot_2" },
        { id: "img_3", kind: "image", imageSlotId: "slot_3" },
      ],
      cssClass: "sec-three-images",
    },
  };

  const map: Record<string, { blocks: any[]; cssClass?: string }> = {};
  rows.forEach((r) => {
    const def = bySlug[r.slug];
    if (def) map[r.id] = def;
  });
  return map;
}

/* ------------------------------------------------------------------ */
/* Load a template with its section rows (for adapter mode)            */
/* ------------------------------------------------------------------ */
async function loadTemplateWithSections(
  templateId: string
): Promise<TemplateDef | null> {
  const { data: t } = await supabase
    .from("templates")
    .select("*")
    .eq("id", templateId)
    .single();
  if (!t) return null;

  const { data: ts } = await supabase
    .from("template_sections")
    .select("section_type_id, sort_order")
    .eq("template_id", templateId)
    .order("sort_order", { ascending: true });

  return {
    id: t.id,
    name: t.name,
    sections: (ts || []).map((row: any) => ({
      sectionTypeId: row.section_type_id as string,
    })),
  } as TemplateDef;
}

/* ------------------------------------------------------------------ */
/* Composer for one article part                                       */
/* ------------------------------------------------------------------ */
function PartComposer({
  siteId,
  label,
  text,
  templateId,
  onTemplateChange,
  onTextChange,
  onExportSnapshot,
}: {
  siteId: string | number;
  label: string;
  text: string;
  templateId?: string | null;
  onTemplateChange: (id: string | null) => void;
  onTextChange: (v: string) => void;
  onExportSnapshot: (snapshot: { html: string; json: any }) => void;
}) {
  const [archetypes, setArchetypes] = useState<SectionTypeRow[]>([]);
  const [catalog, setCatalog] = useState<Record<string, { blocks: any[] }>>({});
  const [templates, setTemplates] = useState<{ id: string; name: string }[]>(
    []
  );
  const [tpl, setTpl] = useState<TemplateDef | null>(null);

  // gallery
  const [showGallery, setShowGallery] = useState(false);
  const pickImage = async (slotId: string) =>
    new Promise<any>((resolve) => {
      setShowGallery(true);
      (window as any).__pick = (img: any) => {
        setShowGallery(false);
        resolve({
          slotId,
          src: img.publicUrl,
          alt: img.alt_text || "",
          caption: img.caption || null,
        });
      };
    });

  useEffect(() => {
    // one-time bootstrap: seed defaults, load archetype rows + templates list
    let cancelled = false;
    (async () => {
      await seedDefaultSectionTypes(DEFAULT_SETTINGS);
      const rows = await loadArchetypeRows();
      if (!cancelled) {
        setArchetypes(rows);
        setCatalog(catalogFromRows(rows));
      }
      const tpls = await loadTemplates();
      if (!cancelled) setTemplates((tpls.rows as any) || []);
    })();
    return () => {
      cancelled = true;
    };
  }, []); // stable

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!templateId) {
        setTpl(null);
        return;
      }
      const def = await loadTemplateWithSections(templateId);
      if (!cancelled) setTpl(def);
    })();
    return () => {
      cancelled = true;
    };
  }, [templateId]);

  // Export button (optional; here we just hand the snapshot back up)
  const exportSnapshot = async (html: string, layout: any) => {
    onExportSnapshot({ html, json: layout });
  };

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-3 md:p-4">
      <div className="mb-2 text-sm font-semibold text-gray-700">{label}</div>

      <textarea
        className={`${inputStyles} min-h-[160px]`}
        value={text}
        onChange={(e) => onTextChange(e.target.value)}
        placeholder="Plain text for this section"
      />

      <div className="mt-3">
        <select
          className={inputStyles}
          value={templateId || ""}
          onChange={(e) => onTemplateChange(e.target.value || null)}
        >
          <option value="">— Select template —</option>
          {templates.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
      </div>

      <div className="mt-4">
        {tpl ? (
          <FlowComposer
            masterText={text}
            template={tpl}
            sectionCatalog={catalog}
            debugFrames
            onPickImage={(slot) => pickImage(slot)}
          />
        ) : (
          <div className="text-sm text-gray-500">
            Pick a template to preview and assign images.
          </div>
        )}
      </div>

      <GalleryBrowserModal
        show={showGallery}
        onClose={() => setShowGallery(false)}
        onImageSelect={(img) => {
          const fn = (window as any).__pick;
          if (typeof fn === "function") fn(img);
        }}
        siteId={siteId}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Main export                                                        */
/* ------------------------------------------------------------------ */

export default function ArticlesSection({
  siteId,
  history_content,
  architecture_content,
  climate_env_content,
  history_layout_html,
  architecture_layout_html,
  climate_layout_html,
  history_template_id,
  architecture_template_id,
  climate_template_id,
  onChange,
}: {
  siteId: string | number;
  history_content: string;
  architecture_content?: string;
  climate_env_content?: string;
  history_layout_html?: string;
  architecture_layout_html?: string;
  climate_layout_html?: string;
  history_template_id?: string | null;
  architecture_template_id?: string | null;
  climate_template_id?: string | null;
  onChange: (patch: any) => void;
}) {
  return (
    <>
      <FieldBlock label="History & Background">
        <PartComposer
          siteId={siteId}
          label="History & Background"
          text={history_content || ""}
          templateId={history_template_id || null}
          onTemplateChange={(id) => onChange({ history_template_id: id })}
          onTextChange={(v) => onChange({ history_content: v })}
          onExportSnapshot={({ html, json }) =>
            onChange({ history_layout_html: html, history_layout_json: json })
          }
        />
      </FieldBlock>

      <div className="mt-6">
        <FieldBlock label="Architecture & Design (optional)">
          <PartComposer
            siteId={siteId}
            label="Architecture & Design"
            text={architecture_content || ""}
            templateId={architecture_template_id || null}
            onTemplateChange={(id) =>
              onChange({ architecture_template_id: id })
            }
            onTextChange={(v) => onChange({ architecture_content: v })}
            onExportSnapshot={({ html, json }) =>
              onChange({
                architecture_layout_html: html,
                architecture_layout_json: json,
              })
            }
          />
        </FieldBlock>
      </div>

      <div className="mt-6">
        <FieldBlock label="Climate, Geography & Environment (optional)">
          <PartComposer
            siteId={siteId}
            label="Climate, Geography & Environment"
            text={climate_env_content || ""}
            templateId={climate_template_id || null}
            onTemplateChange={(id) => onChange({ climate_template_id: id })}
            onTextChange={(v) => onChange({ climate_env_content: v })}
            onExportSnapshot={({ html, json }) =>
              onChange({ climate_layout_html: html, climate_layout_json: json })
            }
          />
        </FieldBlock>
      </div>
    </>
  );
}
