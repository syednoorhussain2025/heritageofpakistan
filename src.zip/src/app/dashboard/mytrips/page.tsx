export default function MyTripsPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold">My Trips</h1>
      <p>This is a placeholder for the My Trips page.</p>
    </div>
  );
}
