export default function RecommendationsPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold">Recommendations</h1>
      <p>This is a placeholder for the Recommendations page.</p>
    </div>
  );
}
