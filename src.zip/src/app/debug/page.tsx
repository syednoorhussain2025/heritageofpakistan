export const dynamic = "force-static"; // optional
import DebugAsideWrap from "./DebugAsideWrap";

export default function Page() {
  return <DebugAsideWrap />;
}
