// src/components/SearchFilters.tsx
"use client";

import { useState, useMemo, useEffect, useRef } from "react";
import { supabase } from "@/lib/supabaseClient";
import Icon from "./Icon";

export type FilterOptions = {
  categories: Option[];
  regions: Option[];
};
export type Filters = {
  name: string;
  categoryIds: string[];
  regionIds: string[];
  orderBy: string;
};
type Option = { id: string; name: string; icon_key: string | null };

const useClickOutside = (ref: any, handler: () => void) => {
  useEffect(() => {
    const listener = (event: MouseEvent | TouchEvent) => {
      if (!ref.current || ref.current.contains(event.target as Node)) return;
      handler();
    };
    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);
    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [ref, handler]);
};

/* ───────────────────────────── MultiSelectDropdown (restyled) ───────────────────────────── */
const MultiSelectDropdown = ({
  options,
  selectedIds,
  onChange,
  placeholder,
  exampleText,
}: {
  options: Option[];
  selectedIds: string[];
  onChange: (ids: string[]) => void;
  placeholder: string;
  exampleText?: string;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef(null);
  useClickOutside(dropdownRef, () => setIsOpen(false));

  const filteredOptions = options.filter((opt) =>
    opt.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const selectedOptions = useMemo(
    () => options.filter((opt) => (selectedIds || []).includes(opt.id)),
    [options, selectedIds]
  );

  const toggleOption = (id: string) => {
    const currentIds = selectedIds || [];
    const newSelectedIds = currentIds.includes(id)
      ? currentIds.filter((sid) => sid !== id)
      : [...currentIds, id];
    onChange(newSelectedIds);
  };

  const displayLabel = useMemo(() => {
    if (!selectedOptions || selectedOptions.length === 0)
      return exampleText || "";
    if (selectedOptions.length === 1) return selectedOptions[0].name;
    return selectedOptions[0].name;
  }, [selectedOptions, exampleText]);

  const plusMoreTooltipLabel = useMemo(() => {
    if (!selectedOptions || selectedOptions.length <= 1) return "";
    return selectedOptions
      .slice(1)
      .map((opt) => opt.name)
      .join("\n");
  }, [selectedOptions]);

  return (
    <div className="relative group" ref={dropdownRef}>
      <div
        className={`relative border-b-2 transition-colors ${
          isOpen
            ? "border-[var(--mustard-accent)]"
            : "border-[var(--taupe-grey)] group-hover:border-[var(--mustard-accent)]"
        }`}
      >
        <label className="block text-xs font-medium text-[var(--espresso-brown)]/70 pt-2">
          {placeholder}
        </label>
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center justify-between text-left pt-1 pb-2"
        >
          <div
            className={`text-base truncate ${
              !selectedIds || selectedIds.length === 0
                ? "text-[var(--espresso-brown)]/60 font-normal"
                : "text-[var(--dark-grey)] font-semibold"
            }`}
          >
            {selectedOptions.length > 1 ? (
              <div className="flex items-center">
                <span className="truncate">{displayLabel},</span>
                <span
                  className="relative group/plus ml-1 flex-shrink-0"
                  title={plusMoreTooltipLabel}
                >{`+${selectedOptions.length - 1}`}</span>
              </div>
            ) : (
              displayLabel || "\u00A0"
            )}
          </div>
          <div className="flex items-center space-x-3">
            {selectedIds && selectedIds.length > 0 && (
              <div
                role="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onChange([]);
                }}
                className="w-5 h-5 rounded-full bg-[var(--ivory-cream)] ring-1 ring-[var(--taupe-grey)] flex items-center justify-center text-[var(--taupe-grey)] hover:text-[var(--terracotta-red)] hover:bg-white transition-colors"
                title="Clear selection"
              >
                <Icon name="times" size={10} />
              </div>
            )}
            <Icon
              name="chevron-down"
              size={16}
              className={`transition-transform text-[var(--taupe-grey)] ${
                isOpen ? "rotate-180" : ""
              }`}
            />
          </div>
        </button>
      </div>
      <div
        className={`absolute left-0 right-0 z-20 mt-2 bg-white rounded-xl shadow-2xl ring-1 ring-[var(--taupe-grey)] transition-all duration-300 ease-in-out ${
          isOpen
            ? "opacity-100 translate-y-0"
            : "opacity-0 -translate-y-2 pointer-events-none"
        }`}
      >
        <div className="p-2 border-b border-[var(--taupe-grey)]/50">
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full px-2 py-1.5 text-sm transition-colors rounded-md focus:outline-none focus:ring-2 focus:ring-[var(--mustard-accent)] placeholder-[var(--espresso-brown)]/60 ${
              searchTerm
                ? "bg-white"
                : "bg-[var(--ivory-cream)] hover:bg-[var(--ivory-cream)]/80"
            } text-[var(--dark-grey)]`}
          />
        </div>
        <ul className="py-2 max-h-60 overflow-auto">
          {filteredOptions.map((opt) => (
            <li
              key={opt.id}
              onClick={() => toggleOption(opt.id)}
              className={`px-3 py-2 cursor-pointer transition-colors font-explore-dropdown-item ${
                selectedIds && selectedIds.includes(opt.id)
                  ? "bg-[var(--terracotta-red)]/10 text-[var(--terracotta-red)] font-semibold"
                  : "hover:bg-[var(--ivory-cream)]"
              } text-[var(--dark-grey)]`}
            >
              {opt.name}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

interface SearchFiltersProps {
  filters: Filters;
  onFilterChange: (newFilters: Partial<Filters>) => void;
  onSearch: () => void;
}

export default function SearchFilters({
  filters,
  onFilterChange,
  onSearch,
}: SearchFiltersProps) {
  const [options, setOptions] = useState<FilterOptions>({
    categories: [],
    regions: [],
  });
  const [activeTab, setActiveTab] = useState<"filters" | "cats" | "regs">(
    "filters"
  );
  const [catSearch, setCatSearch] = useState("");
  const [regSearch, setRegSearch] = useState("");

  useEffect(() => {
    (async () => {
      const [{ data: cat }, { data: reg }] = await Promise.all([
        supabase.from("categories").select("id,name,icon_key").order("name"),
        supabase.from("regions").select("id,name,icon_key").order("name"),
      ]);
      setOptions({
        categories: (cat as Option[]) || [],
        regions: (reg as Option[]) || [],
      });
    })();
  }, []);

  const filteredCategories = options.categories.filter((c) =>
    c.name.toLowerCase().includes(catSearch.toLowerCase())
  );
  const filteredRegions = options.regions.filter((r) =>
    r.name.toLowerCase().includes(regSearch.toLowerCase())
  );

  const handleCategoryClick = (id: string) => {
    onFilterChange({ categoryIds: [id], regionIds: [] });
  };

  const handleRegionClick = (id: string) => {
    onFilterChange({ regionIds: [id], categoryIds: [] });
  };

  const handleReset = () => {
    onFilterChange({
      name: "",
      categoryIds: [],
      regionIds: [],
      orderBy: "latest",
    });
  };

  return (
    <div className="p-4 bg-white h-full flex flex-col">
      {/* Tabs */}
      <div className="flex gap-2 mb-4">
        {(["filters", "cats", "regs"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setActiveTab(t)}
            className={`font-explore-tab px-3 py-1.5 rounded-full text-sm font-semibold border transition ${
              activeTab === t
                ? "bg-[var(--terracotta-red)] text-white border-[var(--terracotta-red)]"
                : "bg-white text-[var(--dark-grey)] border-[var(--taupe-grey)] hover:bg-[var(--ivory-cream)]"
            }`}
          >
            {t === "filters"
              ? "Filters"
              : t === "cats"
              ? "Categories"
              : "Regions"}
          </button>
        ))}
      </div>

      {/* Panels */}
      <div className="flex-grow min-h-0">
        {activeTab === "filters" && (
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-medium text-[var(--espresso-brown)]/70">
                Search by Name
              </label>
              <input
                type="text"
                value={filters.name}
                onChange={(e) => onFilterChange({ name: e.target.value })}
                onKeyDown={(e) => e.key === "Enter" && onSearch()}
                placeholder="e.g., Lahore Fort"
                className="w-full bg-transparent border-0 border-b-2 border-[var(--taupe-grey)] hover:border-[var(--mustard-accent)] focus:border-[var(--mustard-accent)] focus:ring-0 focus:outline-none px-0 py-2 transition-colors font-explore-input placeholder-[var(--espresso-brown)]/60 text-[var(--dark-grey)]"
              />
            </div>

            <MultiSelectDropdown
              options={options.categories}
              selectedIds={filters.categoryIds}
              onChange={(ids) => onFilterChange({ categoryIds: ids })}
              placeholder="Heritage Type"
              exampleText="e.g., Forts"
            />

            <MultiSelectDropdown
              options={options.regions}
              selectedIds={filters.regionIds}
              onChange={(ids) => onFilterChange({ regionIds: ids })}
              placeholder="Region"
              exampleText="e.g., Sindh"
            />

            <div>
              <label className="block text-xs font-medium text-[var(--espresso-brown)]/70">
                Order by
              </label>
              <select
                value={filters.orderBy}
                onChange={(e) => onFilterChange({ orderBy: e.target.value })}
                className="w-full bg-transparent border-0 border-b-2 border-[var(--taupe-grey)] hover:border-[var(--mustard-accent)] focus:border-[var(--mustard-accent)] focus:ring-0 focus:outline-none px-0 py-2 transition-colors font-explore-input text-[var(--dark-grey)]"
              >
                <option value="top">Top rated</option>
                <option value="latest">Latest</option>
                <option value="az">A–Z</option>
              </select>
            </div>
          </div>
        )}

        {activeTab === "cats" && (
          <div className="h-full flex flex-col">
            <input
              type="text"
              placeholder="Search categories..."
              value={catSearch}
              onChange={(e) => setCatSearch(e.target.value)}
              className="w-full mb-3 px-3 py-2 text-sm bg-[var(--ivory-cream)] rounded-md focus:outline-none focus:ring-2 focus:ring-[var(--mustard-accent)] placeholder-[var(--espresso-brown)]/60 font-explore-input flex-shrink-0"
            />
            <div className="space-y-1 overflow-y-auto scrollbar-hide">
              {filteredCategories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleCategoryClick(c.id)}
                  className={`w-full text-left px-3 py-2 rounded-lg border transition flex items-center gap-2 ${
                    filters.categoryIds.includes(c.id)
                      ? "bg-[var(--terracotta-red)]/10 border-[var(--terracotta-red)]"
                      : "border-[var(--taupe-grey)] hover:bg-[var(--ivory-cream)]"
                  }`}
                >
                  <Icon
                    name={c.icon_key || "folder"}
                    size={16}
                    className="text-[var(--taupe-grey)]"
                  />
                  <span className="font-explore-tab-item text-[var(--dark-grey)]">
                    {c.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTab === "regs" && (
          <div className="h-full flex flex-col">
            <input
              type="text"
              placeholder="Search regions..."
              value={regSearch}
              onChange={(e) => setRegSearch(e.target.value)}
              className="w-full mb-3 px-3 py-2 text-sm bg-[var(--ivory-cream)] rounded-md focus:outline-none focus:ring-2 focus:ring-[var(--mustard-accent)] placeholder-[var(--espresso-brown)]/60 font-explore-input flex-shrink-0"
            />
            <div className="space-y-1 overflow-y-auto scrollbar-hide">
              {filteredRegions.map((r) => (
                <button
                  key={r.id}
                  onClick={() => handleRegionClick(r.id)}
                  className={`w-full text-left px-3 py-2 rounded-lg border transition flex items-center gap-2 ${
                    filters.regionIds.includes(r.id)
                      ? "bg-[var(--terracotta-red)]/10 border-[var(--terracotta-red)]"
                      : "border-[var(--taupe-grey)] hover:bg-[var(--ivory-cream)]"
                  }`}
                >
                  <Icon
                    name={r.icon_key || "map"}
                    size={16}
                    className="text-[var(--taupe-grey)]"
                  />
                  <span className="font-explore-tab-item text-[var(--dark-grey)]">
                    {r.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer actions */}
      <div className="flex gap-3 pt-4 mt-4 flex-shrink-0">
        <button
          onClick={onSearch}
          className="font-explore-button flex-1 py-2 rounded-xl bg-[var(--terracotta-red)] hover:brightness-95 text-white font-semibold shadow-lg transition-colors focus:outline-none focus:ring-2 focus:ring-[var(--mustard-accent)]"
        >
          Search
        </button>
        <button
          onClick={handleReset}
          className="font-explore-button px-4 rounded-xl bg-white ring-1 ring-[var(--taupe-grey)] shadow-sm text-[var(--dark-grey)] hover:bg-[var(--ivory-cream)] inline-flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-[var(--mustard-accent)]"
          title="Reset filters"
          type="button"
        >
          <Icon
            name="redo-alt"
            size={14}
            className="text-[var(--terracotta-red)]"
          />{" "}
          Reset
        </button>
      </div>
    </div>
  );
}
