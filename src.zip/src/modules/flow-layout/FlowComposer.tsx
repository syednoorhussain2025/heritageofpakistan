// src/modules/flow-layout/FlowComposer.tsx
"use client";

import * as React from "react";

/* ----------------------------- Types ----------------------------- */

export type SectionKind =
  | "full-width-image"
  | "image-left-text-right"
  | "image-right-text-left"
  | "two-images"
  | "three-images"
  | "full-width-text";

export type ImageSlot = {
  src?: string;
  alt?: string | null;
  caption?: string | null;
  href?: string | null;
  aspectRatio?: number; // e.g. 1.777 for 16:9
  /** NEW: when using adapter mode we carry the source slot id so the picker knows what to fill */
  slotId?: string;
};

export type TextSlot = {
  html?: string;
  text?: string;
};

export type Section = {
  id?: string;
  type: SectionKind;
  images?: ImageSlot[];
  text?: TextSlot;
  paddingY?: "none" | "sm" | "md" | "lg";
  bg?: "none" | "muted";
};

export type FlowComposerProps = {
  /** Classic mode (unchanged) */
  sections?: Section[] | null;
  debugFrames?: boolean;

  /** ---------- Adapter/Test mode (all optional; activate if template+sectionCatalog provided) ---------- */
  masterText?: string;
  template?: {
    id: string;
    name?: string;
    sections: Array<{ sectionTypeId: string }>;
  };
  sectionCatalog?: Record<
    string,
    {
      cssClass?: string;
      blocks: Array<
        | {
            id: string;
            kind: "text";
            acceptsTextFlow?: boolean;
            textPolicy?: { targetWords?: number };
          }
        | { id: string; kind: "image"; imageSlotId: string }
      >;
    }
  >;
  /** supply to enable image picking UI for empty slots */
  onPickImage?: (slotId: string) => Promise<ImageSlot>;
};

/* ---------------------------- Utilities ---------------------------- */

function padY(cls?: Section["paddingY"]) {
  switch (cls) {
    case "none":
      return "";
    case "sm":
      return "py-4";
    case "lg":
      return "py-12";
    case "md":
    default:
      return "py-8";
  }
}

function panel(bg?: Section["bg"]) {
  return bg === "muted"
    ? "bg-white shadow-sm border border-gray-200 rounded-2xl"
    : "";
}

function Placeholder({
  children,
  minH = 240,
}: {
  children: React.ReactNode;
  minH?: number;
}) {
  return (
    <div
      style={{ minHeight: minH }}
      className="grid place-items-center rounded-xl border border-dashed border-gray-300 bg-gray-50 text-gray-500"
    >
      {children}
    </div>
  );
}

function Figure({
  slot,
  onPick,
}: {
  slot: ImageSlot;
  onPick?: (slotId?: string) => void;
}) {
  const hasImg = !!slot.src;
  const wrap =
    typeof slot.aspectRatio === "number" && slot.aspectRatio > 0
      ? { paddingTop: `${(1 / slot.aspectRatio) * 100}%` }
      : null;

  return (
    <figure className="w-full">
      <div
        className={`relative w-full overflow-hidden rounded-xl ${
          hasImg ? "" : "bg-gray-50"
        }`}
        style={wrap || undefined}
      >
        {hasImg ? (
          <>
            {slot.href ? (
              <a
                href={slot.href || undefined}
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src={slot.src}
                  alt={slot.alt || ""}
                  className="w-full h-full object-cover rounded-xl"
                  style={wrap ? { position: "absolute", inset: 0 } : undefined}
                  loading="lazy"
                />
              </a>
            ) : (
              <img
                src={slot.src}
                alt={slot.alt || ""}
                className="w-full h-full object-cover rounded-xl"
                style={wrap ? { position: "absolute", inset: 0 } : undefined}
                loading="lazy"
              />
            )}
          </>
        ) : (
          <Placeholder minH={wrap ? 0 : 260}>
            <div className="flex items-center gap-3">
              <span className="text-sm">Empty slot</span>
              {onPick ? (
                <button
                  className="px-3 py-1.5 rounded-full bg-black text-white text-xs"
                  onClick={() => onPick(slot.slotId)}
                >
                  Pick image
                </button>
              ) : null}
            </div>
          </Placeholder>
        )}
      </div>
      {slot.caption ? (
        <figcaption className="mt-2 text-sm text-gray-500 text-center">
          {slot.caption}
        </figcaption>
      ) : null}
    </figure>
  );
}

function Prose({ text }: { text?: TextSlot }) {
  if (!text) return null;
  if (text.html) {
    return (
      <div
        className="prose prose-gray max-w-none"
        dangerouslySetInnerHTML={{ __html: text.html }}
      />
    );
  }
  if (text.text) {
    return (
      <div className="prose prose-gray max-w-none whitespace-pre-wrap">
        {text.text}
      </div>
    );
  }
  return null;
}

/* --------------------------- Archetypes --------------------------- */

function FullWidthImage({
  sec,
  onPickImage,
}: {
  sec: Section;
  onPickImage?: (slotId?: string) => void;
}) {
  const img = sec.images?.[0];
  return (
    <div className={`${padY(sec.paddingY)} ${panel(sec.bg)}`}>
      {img ? (
        <Figure slot={img} onPick={onPickImage} />
      ) : (
        <Placeholder>Image</Placeholder>
      )}
    </div>
  );
}

function ImageLeftTextRight({
  sec,
  onPickImage,
}: {
  sec: Section;
  onPickImage?: (slotId?: string) => void;
}) {
  const img = sec.images?.[0];
  return (
    <div className={`${padY(sec.paddingY)} ${panel(sec.bg)}`}>
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        <div className="md:col-span-5">
          {img ? (
            <Figure slot={img} onPick={onPickImage} />
          ) : (
            <Placeholder>Image</Placeholder>
          )}
        </div>
        <div className="md:col-span-7">
          <Prose text={sec.text} />
        </div>
      </div>
    </div>
  );
}

function ImageRightTextLeft({
  sec,
  onPickImage,
}: {
  sec: Section;
  onPickImage?: (slotId?: string) => void;
}) {
  const img = sec.images?.[0];
  return (
    <div className={`${padY(sec.paddingY)} ${panel(sec.bg)}`}>
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        <div className="md:col-span-7 order-2 md:order-1">
          <Prose text={sec.text} />
        </div>
        <div className="md:col-span-5 order-1 md:order-2">
          {img ? (
            <Figure slot={img} onPick={onPickImage} />
          ) : (
            <Placeholder>Image</Placeholder>
          )}
        </div>
      </div>
    </div>
  );
}

function TwoImages({
  sec,
  onPickImage,
}: {
  sec: Section;
  onPickImage?: (slotId?: string) => void;
}) {
  const imgs = (sec.images || []).slice(0, 2);
  return (
    <div className={`${padY(sec.paddingY)} ${panel(sec.bg)}`}>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {imgs.map((s, i) => (
          <Figure key={i} slot={s} onPick={onPickImage} />
        ))}
      </div>
    </div>
  );
}

function ThreeImages({
  sec,
  onPickImage,
}: {
  sec: Section;
  onPickImage?: (slotId?: string) => void;
}) {
  const imgs = (sec.images || []).slice(0, 3);
  return (
    <div className={`${padY(sec.paddingY)} ${panel(sec.bg)}`}>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {imgs.map((s, i) => (
          <Figure key={i} slot={s} onPick={onPickImage} />
        ))}
      </div>
    </div>
  );
}

function FullWidthText({ sec }: { sec: Section }) {
  return (
    <div className={`${padY(sec.paddingY)} ${panel(sec.bg)}`}>
      <Prose text={sec.text} />
    </div>
  );
}

/* ---------------------- Adapter: catalog → sections ---------------------- */

function detectKind(blocks: Array<any>): SectionKind {
  const imgs = blocks.filter((b) => b.kind === "image").length;
  const txts = blocks.filter((b) => b.kind === "text").length;

  if (imgs === 0 && txts === 1) return "full-width-text";
  if (imgs === 1 && txts === 0) return "full-width-image";
  if (imgs === 2 && txts === 0) return "two-images";
  if (imgs === 3 && txts === 0) return "three-images";

  if (blocks.length === 2) {
    const [a, b] = blocks;
    if (a.kind === "image" && b.kind === "text") return "image-left-text-right";
    if (a.kind === "text" && b.kind === "image") return "image-right-text-left";
  }

  // fallback
  return "full-width-text";
}

function makeSectionsFromTemplate(opts: {
  masterText?: string;
  template: FlowComposerProps["template"];
  sectionCatalog: NonNullable<FlowComposerProps["sectionCatalog"]>;
  pickedImages: Record<string, ImageSlot>;
}): Section[] {
  const { masterText = "", template, sectionCatalog, pickedImages } = opts;

  // naive tokenizer
  const tokens = masterText
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .filter(Boolean);
  let cursor = 0;
  const takeWords = (n?: number) => {
    const k =
      !n || n <= 0
        ? tokens.length - cursor
        : Math.min(n, tokens.length - cursor);
    const slice = tokens.slice(cursor, cursor + k).join(" ");
    cursor += k;
    return slice;
  };

  const out: Section[] = [];

  for (const seg of template!.sections) {
    const cat = sectionCatalog[seg.sectionTypeId];
    if (!cat) continue;

    const kind = detectKind(cat.blocks);

    const images: ImageSlot[] = [];
    let text: TextSlot | undefined;

    cat.blocks.forEach((b) => {
      if (b.kind === "image") {
        const chosen = pickedImages[b.imageSlotId];
        images.push({
          slotId: b.imageSlotId,
          src: chosen?.src,
          alt: chosen?.alt ?? null,
          caption: chosen?.caption ?? null,
          href: chosen?.href ?? null,
        });
      } else if (b.kind === "text") {
        const body = takeWords(b.textPolicy?.targetWords);
        text = { text: body };
      }
    });

    out.push({
      type: kind,
      images,
      text,
      paddingY: "md",
      bg: "none",
    });
  }

  return out;
}

/* ------------------------------ Root ------------------------------ */

export default function FlowComposer(props: FlowComposerProps) {
  const {
    sections,
    debugFrames,

    // adapter
    masterText,
    template,
    sectionCatalog,
    onPickImage,
  } = props;

  // If a sections array was supplied, we use classic mode.
  const classicList: Section[] = Array.isArray(sections)
    ? (sections.filter(Boolean) as Section[])
    : [];

  // Adapter mode state: images chosen by slot id
  const [pickedBySlot, setPickedBySlot] = React.useState<
    Record<string, ImageSlot>
  >({});

  // derived list for adapter mode
  const adapterList: Section[] = React.useMemo(() => {
    if (!template || !sectionCatalog) return [];
    return makeSectionsFromTemplate({
      masterText,
      template,
      sectionCatalog,
      pickedImages: pickedBySlot,
    });
  }, [
    masterText,
    template?.id,
    JSON.stringify(template?.sections),
    sectionCatalog,
    pickedBySlot,
  ]);

  const list = classicList.length ? classicList : adapterList;

  const handlePick = async (slotId?: string) => {
    if (!slotId || !onPickImage) return;
    const picked = await onPickImage(slotId);
    if (!picked) return;
    setPickedBySlot((m) => ({ ...m, [slotId]: picked }));
  };

  if (list.length === 0) {
    return (
      <div className="text-sm text-gray-500">
        {debugFrames ? "No sections in this template yet." : null}
      </div>
    );
  }

  return (
    <div className="space-y-10">
      {list.map((sec, idx) => {
        const key = sec.id || `${sec.type}-${idx}`;
        const wrapCls = debugFrames
          ? "relative ring-1 ring-dashed ring-emerald-300 rounded-xl p-1"
          : "";

        switch (sec.type) {
          case "full-width-image":
            return (
              <div key={key} className={wrapCls}>
                <FullWidthImage sec={sec} onPickImage={handlePick} />
              </div>
            );
          case "image-left-text-right":
            return (
              <div key={key} className={wrapCls}>
                <ImageLeftTextRight sec={sec} onPickImage={handlePick} />
              </div>
            );
          case "image-right-text-left":
            return (
              <div key={key} className={wrapCls}>
                <ImageRightTextLeft sec={sec} onPickImage={handlePick} />
              </div>
            );
          case "two-images":
            return (
              <div key={key} className={wrapCls}>
                <TwoImages sec={sec} onPickImage={handlePick} />
              </div>
            );
          case "three-images":
            return (
              <div key={key} className={wrapCls}>
                <ThreeImages sec={sec} onPickImage={handlePick} />
              </div>
            );
          case "full-width-text":
            return (
              <div key={key} className={wrapCls}>
                <FullWidthText sec={sec} />
              </div>
            );
          default:
            return <div key={key} />;
        }
      })}
    </div>
  );
}
