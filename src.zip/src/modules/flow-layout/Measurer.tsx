"use client";
import { useEffect, useMemo, useRef } from "react";
import type { MeasurerAPI } from "./types";

/**
 * Offscreen measurer. Applies signature classes that **must not contain colons**.
 * We sanitize to allow only [a-zA-Z0-9-_].
 *
 * Expected CSS (example):
 * .hop-measure-base { position: fixed; left: -99999px; top: -99999px; visibility: hidden; pointer-events: none; }
 * .hop-measure-base { white-space: normal; word-break: break-word; overflow: auto; }
 * .sig-...          { // width/font/line-height/etc. encoded by the engine/template as a class signature }
 */
export function useMeasurer(): MeasurerAPI {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (ref.current) return;
    const el = document.createElement("div");
    el.setAttribute("aria-hidden", "true");
    // base placement / invisibility
    el.style.position = "fixed";
    el.style.left = "-99999px";
    el.style.top = "-99999px";
    el.style.visibility = "hidden";
    el.style.pointerEvents = "none";
    // text behavior
    el.style.whiteSpace = "normal";
    el.style.wordBreak = "break-word";
    el.style.overflow = "auto";
    document.body.appendChild(el);
    ref.current = el;
    return () => {
      if (ref.current?.parentNode)
        ref.current.parentNode.removeChild(ref.current);
    };
  }, []);

  const applySignature = (el: HTMLDivElement, cssSignature?: string) => {
    // Reset class list and apply base + sanitized signature
    el.className = "";
    el.classList.add("hop-measure-base");
    if (cssSignature) {
      const safe = cssSignature.replace(/[^a-zA-Z0-9-_]/g, "_");
      // Allow multiple signatures separated by whitespace
      for (const tok of safe.split(/\s+/).filter(Boolean)) {
        el.classList.add(`sig-${tok}`);
      }
    }
  };

  return useMemo<MeasurerAPI>(
    () => ({
      checkOverflow: ({ text, cssSignature, maxHeightPx }) => {
        if (!ref.current) return false;
        const el = ref.current;

        applySignature(el, cssSignature);

        // Content
        el.textContent = text || "";

        // Constraints for overflow check
        if (typeof maxHeightPx === "number") {
          el.style.maxHeight = `${maxHeightPx}px`;
        } else {
          el.style.maxHeight = "";
        }
        // Width is determined by the signature’s CSS; do not force here.
        el.style.width = "";

        // Measure
        return typeof maxHeightPx === "number"
          ? el.scrollHeight > maxHeightPx + 1
          : false;
      },

      // New: precise height measurement under a signature (optionally with explicit width)
      measureTextHeight: ({ text, cssSignature, maxWidthPx }) => {
        if (!ref.current) return 0;
        const el = ref.current;

        applySignature(el, cssSignature);

        // Optional explicit width override
        if (typeof maxWidthPx === "number" && maxWidthPx > 0) {
          el.style.width = `${maxWidthPx}px`;
        } else {
          el.style.width = ""; // use CSS from signature
        }

        // Remove height clamps for a pure measurement
        el.style.maxHeight = "";
        el.style.height = "auto";

        // Content
        el.textContent = text || "";

        // Force layout & read height
        // Use scrollHeight to capture total content height
        const h = el.scrollHeight;
        return Math.max(0, Math.round(h));
      },

      // New: compute image height from standardized sizing info
      computeImageHeightFromSizing: ({ sizing, resolvedWidthPx }) => {
        if (!sizing) return undefined;

        // Determine width in px (priority: resolvedWidthPx from engine tokens > explicit widthPx)
        const width =
          typeof resolvedWidthPx === "number" && resolvedWidthPx > 0
            ? resolvedWidthPx
            : typeof sizing.widthPx === "number" && sizing.widthPx > 0
            ? sizing.widthPx
            : undefined;

        if (!width) return undefined;

        // Aspect ratio (w/h) must be known to compute height deterministically
        const ar =
          typeof sizing.aspectRatio === "number" && sizing.aspectRatio > 0
            ? sizing.aspectRatio
            : undefined;

        if (!ar) return undefined;

        const height = width / ar;
        return Math.max(0, Math.round(height));
      },
    }),
    []
  );
}
