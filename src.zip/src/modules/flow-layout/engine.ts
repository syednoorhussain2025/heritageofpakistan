import {
  FlowEngine,
  FlowInput,
  LayoutInstance,
  BlockInstance,
  SectionDef,
  TextPolicy,
  MeasurerAPI,
} from "./types";

// ───────────── utilities ─────────────

const DEFAULT_SNAP = true;
const SENTENCE_SPLIT = /(?<=\.)\s+|(?<=\?)\s+|(?<=!)\s+/; // simple EN split

const clamp = (n: number, lo: number, hi: number) =>
  Math.max(lo, Math.min(hi, n));

const defaultMin = (p: TextPolicy) =>
  p.minWords ?? Math.round(p.targetWords * 0.75);
const defaultMax = (p: TextPolicy) =>
  p.maxWords ?? Math.round(p.targetWords * 1.25);

// A small growth step when we need to expand text to meet a height target
const growthStep = (policy: TextPolicy) =>
  Math.max(10, Math.round(policy.targetWords * 0.15));

function sliceByWordsFrom(
  text: string,
  startChar: number,
  targetWords: number,
  window: { min: number; max: number },
  snapToSentence: boolean
) {
  const remaining = text.slice(startChar);
  if (!remaining.trim()) return { endChar: startChar, excerpt: "" };

  const tokens = remaining.trim().split(/\s+/);
  const take = clamp(targetWords, window.min, window.max);
  const approx = tokens.slice(0, take).join(" ");
  const endChar = startChar + remaining.indexOf(approx) + approx.length;
  let excerpt = text.slice(startChar, endChar);

  if (snapToSentence) {
    const segment = text.slice(startChar, endChar);
    const sentences = segment.split(SENTENCE_SPLIT);
    if (sentences.length > 1) {
      const allButLast = sentences.slice(0, -1).join(" ").trim();
      if (allButLast.length > 0) {
        const newEnd =
          startChar + segment.indexOf(allButLast) + allButLast.length;
        return { endChar: newEnd, excerpt: text.slice(startChar, newEnd) };
      }
    }
  }
  return { endChar, excerpt };
}

function adjustByFitCheck(
  excerpt: string,
  startChar: number,
  endChar: number,
  policy: TextPolicy,
  measurer?: MeasurerAPI,
  cssSignature?: string,
  maxHeightPx?: number
) {
  if (!measurer || !cssSignature) return { endChar, excerpt };
  const overflows = measurer.checkOverflow({
    text: excerpt,
    cssSignature,
    maxHeightPx,
  });
  if (!overflows) return { endChar, excerpt };

  // Remove the last sentence to relieve overflow
  const sentences = excerpt.split(SENTENCE_SPLIT);
  if (sentences.length <= 1) return { endChar, excerpt };

  const trimmed = sentences.slice(0, -1).join(" ").trim();
  const delta = excerpt.length - trimmed.length;
  return { endChar: endChar - delta, excerpt: trimmed };
}

function lockActiveForBreakpoint(
  section: SectionDef,
  bp: FlowInput["breakpoint"]
) {
  const lock = section.textFlowLock;
  if (!lock) return false;
  if (!lock.breakpoints || lock.breakpoints.length === 0) return true;
  return lock.breakpoints.includes(bp);
}

function resolveImageHeightPx(
  section: SectionDef,
  breakpoint: FlowInput["breakpoint"],
  input: FlowInput,
  measurer?: MeasurerAPI
): number | undefined {
  if (!measurer?.computeImageHeightFromSizing) return undefined;
  const lock = section.textFlowLock;
  if (!lock) return undefined;

  const refBlock = section.blocks.find(
    (b) => b.id === lock.minHeightFromBlockId
  );
  if (!refBlock || refBlock.kind !== "image") return undefined;

  // Prepare sizing (prefer block.sizing, but fall back to aspectRatio if defined)
  const sizing =
    refBlock.sizing ??
    (typeof refBlock.aspectRatio === "number"
      ? { aspectRatio: refBlock.aspectRatio }
      : undefined);

  if (!sizing) return undefined;

  let resolvedWidthPx: number | undefined = undefined;
  if (sizing.widthToken && input.designTokens?.widthPx) {
    const tokenPx = input.designTokens.widthPx[sizing.widthToken];
    if (typeof tokenPx === "number" && tokenPx > 0) resolvedWidthPx = tokenPx;
  }
  if (typeof sizing.widthPx === "number" && sizing.widthPx > 0) {
    resolvedWidthPx = sizing.widthPx; // explicit width overrides token
  }

  return measurer.computeImageHeightFromSizing({ sizing, resolvedWidthPx });
}

function allowedOvershootPx(section: SectionDef, targetMinPx: number): number {
  const lock = section.textFlowLock!;
  const pct = typeof lock.overshootPct === "number" ? lock.overshootPct : 0.1;
  const cap = typeof lock.overshootPx === "number" ? lock.overshootPx : 64;
  const pctPx = targetMinPx * pct;
  // Allow up to the smaller of (percentage, absolute cap)
  return Math.min(pctPx, cap);
}

// ───────────── engine ─────────────

export const computeLayout: FlowEngine = (
  input: FlowInput,
  measurer?: MeasurerAPI
): LayoutInstance => {
  const { template, sectionCatalog, text, breakpoint } = input;
  let cursor = 0; // char offset into master text
  const flow: BlockInstance[] = [];

  // Keep a running index so the same section type used multiple times remains distinguishable
  const sectionCounters: Record<string, number> = {};

  for (const tplSection of template.sections) {
    const section: SectionDef = sectionCatalog[tplSection.sectionTypeId];
    if (!section) continue;

    const instanceIndex = (sectionCounters[section.sectionTypeId] ?? 0) + 1;
    sectionCounters[section.sectionTypeId] = instanceIndex;
    const sectionInstanceKey = `${section.sectionTypeId}#${instanceIndex}`;

    const geom = section.geometry[breakpoint];

    // Precompute lock intent + target image height if applicable
    const lockApplies =
      lockActiveForBreakpoint(section, breakpoint) && !!section.textFlowLock;
    const targetImageHeightPx = lockApplies
      ? resolveImageHeightPx(section, breakpoint, input, measurer)
      : undefined;

    for (const block of section.blocks) {
      if (block.kind === "image") {
        flow.push({
          type: "image",
          sectionTypeId: section.sectionTypeId,
          sectionInstanceKey,
          blockId: block.id,
          imageSlotId:
            block.imageSlotId ?? `${section.sectionTypeId}:${block.id}`,
          image: null,
        });
        continue;
      }

      if (block.kind === "text" && (block.acceptsTextFlow ?? false)) {
        const policy = block.textPolicy!;
        const snap = policy.snapToSentence ?? DEFAULT_SNAP;
        const minW = defaultMin(policy);
        const maxW = defaultMax(policy);

        const remaining = text.slice(cursor).trim();
        if (!remaining) continue;

        // 1) Initial quota-based slice
        const { endChar: plannedEnd, excerpt: plannedExcerpt } =
          sliceByWordsFrom(
            text,
            cursor,
            policy.targetWords,
            { min: minW, max: maxW },
            snap
          );

        // SAFE signature: use double-underscore instead of colons
        const cssSignature = `${section.sectionTypeId}__${block.id}__${breakpoint}`;

        // 2) Optional single overflow check against a max height (legacy behavior)
        const { endChar: afterFitEnd, excerpt: afterFitExcerpt } =
          adjustByFitCheck(
            plannedExcerpt,
            cursor,
            plannedEnd,
            policy,
            measurer,
            cssSignature,
            block.maxHeightPx ??
              (geom.heightPolicy.type === "fixed"
                ? geom.heightPolicy.px
                : undefined)
          );

        // 3) Height-lock: grow excerpt until text height >= image height (if applicable)
        let finalEnd = afterFitEnd;
        let finalExcerpt = afterFitExcerpt;
        let minHeightPxForSnapshot: number | undefined = undefined;

        if (
          lockApplies &&
          typeof targetImageHeightPx === "number" &&
          targetImageHeightPx > 0 &&
          measurer?.measureTextHeight
        ) {
          const targetMin = Math.round(targetImageHeightPx);
          const overshootCap = allowedOvershootPx(section, targetMin);
          minHeightPxForSnapshot = targetMin;

          // Measure current excerpt height
          let currentH = measurer.measureTextHeight({
            text: finalExcerpt,
            cssSignature,
          });

          // Grow while below the target
          if (currentH < targetMin) {
            // Increase in steps until we meet the target or run out of text
            let growTarget = policy.targetWords + growthStep(policy);

            // Hard upper bound to avoid pathological loops
            const hardMaxWords = Math.max(maxW, policy.targetWords + 5000);

            while (
              currentH < targetMin &&
              growTarget <= hardMaxWords &&
              finalEnd < text.length
            ) {
              const { endChar: gEnd, excerpt: gEx } = sliceByWordsFrom(
                text,
                cursor,
                growTarget,
                { min: growTarget, max: growTarget }, // exact attempt
                snap
              );
              finalEnd = gEnd;
              finalExcerpt = gEx;

              currentH = measurer.measureTextHeight({
                text: finalExcerpt,
                cssSignature,
              });

              growTarget += growthStep(policy);
            }

            // If we overshot too much, try backing off the last sentence
            if (currentH > targetMin + overshootCap) {
              const sentences = finalExcerpt.split(SENTENCE_SPLIT);
              if (sentences.length > 1) {
                const trimmed = sentences.slice(0, -1).join(" ").trim();
                const newH = measurer.measureTextHeight({
                  text: trimmed,
                  cssSignature,
                });
                if (newH >= targetMin) {
                  const delta = finalExcerpt.length - trimmed.length;
                  finalExcerpt = trimmed;
                  finalEnd = finalEnd - delta;
                  currentH = newH;
                }
              }
            }
          }
        }

        if (!finalExcerpt.trim()) continue;

        flow.push({
          type: "text",
          sectionTypeId: section.sectionTypeId,
          sectionInstanceKey,
          blockId: block.id,
          startChar: cursor,
          endChar: finalEnd,
          minHeightPx: minHeightPxForSnapshot, // persisted for snapshot inlining
        });

        cursor = finalEnd;
      }
    }

    if ((template.truncateOnTextEnd ?? true) && cursor >= text.length) {
      break;
    }
  }

  let leftoverText: LayoutInstance["leftoverText"] = null;
  if (
    cursor < text.length &&
    (template.overflowStrategy ?? "continue") === "stop"
  ) {
    leftoverText = { startChar: cursor };
  }

  return {
    templateId: template.templateId,
    templateVersion: template.version,
    breakpoint,
    flow,
    leftoverText,
  };
};
